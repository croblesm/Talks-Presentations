SQLDiagCmd
==========

Standalone (no install) runner for Glenn Berry's SQL Server Diagnostic Scripts.

Download the diagnostic script that targets your version of SQL Server from 
https://www.sqlskills.com/blogs/glenn/category/dmv-queries/ 

See the wiki (https://github.com/Mitch-Wheat/SQLDiagCmd/wiki) for instructions on how to run.
